import 'dart:async';

import 'package:estudosflame/actors/ember.dart';
import 'package:estudosflame/ember_quest.dart';
import 'package:flame/collisions.dart';
import 'package:flame/components.dart';

import 'package:flame_rive/flame_rive.dart';

class DragonEnemy extends RiveComponent with HasGameRef<EmberQuestGame>,CollisionCallbacks{
  final Artboard dragonArtBoard;
   final Vector2 gridPosition;
   double xOffset;
   bool atack = false;

final Vector2 velocity = Vector2.zero();
  DragonEnemy({required this.dragonArtBoard,
   required this.gridPosition,
    required this.xOffset,

 } ) : super(artboard: dragonArtBoard, size: Vector2.all(264));


  @override
  FutureOr<void> onLoad() {
    add(RectangleHitbox(collisionType: CollisionType.passive));

        position = Vector2(
      (gridPosition.x * size.x) + xOffset + (size.x / 2),
      game.size.y - (gridPosition.y * size.y) - (size.y / 2),
    );


   
    return super.onLoad();
  }

   @override
     void onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {

         if (other is EmberPlayer) {
          atack = true;
          print('relou no pai !');
          game.atackTrigger!.fire();
    
    }
       super.onCollision(intersectionPoints, other);
     
   }

  @override
  void update(double dt)async {
     velocity.x = game.objectSpeed;
    position += velocity * dt;
    if (position.x < -size.x) removeFromParent();
    if (position.x < -size.x || game.health <= 0) {
  removeFromParent();
}
       
    super.update(dt);

  }

}