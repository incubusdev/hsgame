<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Room_Builder_Office_HS2_16x16" tilewidth="16" tileheight="16" tilecount="224" columns="16">
 <image source="../Desktop/tileSetsFULL/Modern_Office_Revamped/1_Room_Builder_Office/Room_Builder_Office_HS2_16x16.png" trans="ff00ff" width="256" height="224"/>
</tileset>
