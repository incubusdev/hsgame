import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:highsoftgame/HisoftGame/highsoft_game.dart';
import 'package:highsoftgame/HisoftGame/obstaculos.dart';

class HsEmployed extends SpriteAnimationComponent
    with CollisionCallbacks, HasGameRef<HisoftGame> {


  double maxSpeed = 100.0;
  late final Vector2 _lastSize = size.clone();
  late final Transform2D _lastTransform = transform.clone();
  bool emplyedFlipped  = true;
  bool obstacleTouch  = false;

  final JoystickComponent joystick;
  HsEmployed({required this.joystick})
      : super(size: Vector2(16, 32), anchor: Anchor.center);

  @override
  Future<void> onLoad() async {
    animation = SpriteAnimation.fromFrameData(
      await game.images.load('bob_run.png'),
      SpriteAnimationData.sequenced(
        amount: 6,
        textureSize: Vector2(16, 32),
        stepTime: 0.20,
      ),
    );
    position = Vector2(600, 1500);
    add(
      CircleHitbox(),
    );
   
  }

  @override
  void update(double dt) {
    maxSpeed = 100.0;
    obstacleTouch = false;
    if (!joystick.delta.isZero() && activeCollisions.isEmpty) {
      _lastSize.setFrom(size);
      _lastTransform.setFrom(transform);
      position.add(joystick.relativeDelta * maxSpeed * dt);
      // angle = joystick.delta.screenAngle();
    }
    if(joystick.relativeDelta[0] < 0 && emplyedFlipped ){
      emplyedFlipped = false;
      flipHorizontallyAroundCenter();
    }
    if(joystick.relativeDelta[0] > 0 && !emplyedFlipped ){
      emplyedFlipped = true;
      flipHorizontallyAroundCenter();
    }
    
    super.update(dt);
  }

  @override
  void onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
    
    super.onCollision(intersectionPoints, other);
    if(other is Obstaculos){
      maxSpeed = 0 ;
      obstacleTouch = true;
    }
  }

  @override
  void onCollisionStart(
    Set<Vector2> intersectionPoints,
    PositionComponent other,
  ) {
    super.onCollisionStart(intersectionPoints, other);
    transform.setFrom(_lastTransform);
    size.setFrom(_lastSize);
  
  
  }
}
