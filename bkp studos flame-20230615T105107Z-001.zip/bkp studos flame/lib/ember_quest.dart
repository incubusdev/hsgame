import 'package:estudosflame/actors/ember.dart';
import 'package:estudosflame/actors/water_enemy.dart';
import 'package:estudosflame/managers/segment_manager.dart';
import 'package:estudosflame/objects/ground_block.dart';
import 'package:estudosflame/objects/platform_block.dart';
import 'package:estudosflame/objects/star.dart';
import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flame/input.dart';
import 'package:flutter/material.dart';

 
class EmberQuestGame extends FlameGame with HasKeyboardHandlerComponents, HasCollisionDetection {
  EmberQuestGame();

  late EmberPlayer _ember;
  double objectSpeed = 0.0;
  late double lastBlockXPosition = 0.0;
  late UniqueKey lastBlockKey;

  final world = World();
  late final CameraComponent cameraComponent;

  @override
  Future<void> onLoad()async {
      await images.loadAll(
        [
      'block.png',
      'ember.png',
      'ground.png',
      'heart_half.png',
      'heart.png',
      'star.png',
      'water_enemy.png',
        ]
      );
         cameraComponent = CameraComponent(world: world);

    cameraComponent.viewfinder.anchor = Anchor.topLeft;
    addAll([cameraComponent, world]);

  

    initializeGame();

  }

  void initializeGame() {
    // Assume that size.x < 3200
    final segmentsToLoad = (size.x / 640).ceil();
    segmentsToLoad.clamp(0, segments.length);

    for (var i = 0; i <= segmentsToLoad; i++) {
      loadGameSegments(i, (640 * i).toDouble());
    }

    _ember = EmberPlayer(
      position: Vector2(128, canvasSize.y - 128),
    );
    world.add(_ember);
  }

  void loadGameSegments(int segmentIndex, double xPositionOffset) {
    for (final block in segments[segmentIndex]) {
      switch (block.blockType) {
        case GroundBlock:
        add(
      GroundBlock(
        gridPosition: block.gridPosition,
        xOffset: xPositionOffset,
      ),
    );
          break;
        case PlatformBlock:
         add(PlatformBlock(
      gridPosition: block.gridPosition,
      xOffset: xPositionOffset,
    ));
          break;
        case Star:
         add(
      Star(
        gridPosition: block.gridPosition,
        xOffset: xPositionOffset,
      ),
    );
          break;
        case WaterEnemy:
         add(
      WaterEnemy(
       gridPosition: block.gridPosition,
       xOffset: xPositionOffset,
      ),
    );
          break;
      }
    }
  }
  @override
Color backgroundColor() {
    return const Color.fromARGB(255, 173, 223, 247);
}
}